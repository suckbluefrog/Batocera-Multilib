################################################################################
#
# wine-tkg-bin (prebuilt x86_64 Wine for Box64)
#
################################################################################

WINE_TKG_BIN_VERSION = 11.1
WINE_TKG_BIN_SITE = https://github.com/Kron4ek/Wine-Builds/releases/download/$(WINE_TKG_BIN_VERSION)
WINE_TKG_BIN_SOURCE = wine-$(WINE_TKG_BIN_VERSION)-staging-tkg-amd64-wow64.tar.xz

WINE_TKG_BIN_LICENSE = LGPL-2.1+
WINE_TKG_BIN_LICENSE_FILES = LICENSE COPYING.LIB

# This is a foreign-arch payload, not a native package
WINE_TKG_BIN_DEPENDENCIES =

# Do NOT run configure / build
WINE_TKG_BIN_INSTALL_STAGING = NO
WINE_TKG_BIN_INSTALL_TARGET = YES

# Where we want Wine to live
WINE_TKG_BIN_PREFIX = /usr/wine/wine-tkg

define WINE_TKG_BIN_EXTRACT_CMDS
	$(TAR) -xf $(DL_DIR)/$(WINE_TKG_BIN_SOURCE) -C $(@D)
endef

define WINE_TKG_BIN_INSTALL_TARGET_CMDS
	mkdir -p $(TARGET_DIR)$(WINE_TKG_BIN_PREFIX)
	cp -a $(@D)/wine-*/* $(TARGET_DIR)$(WINE_TKG_BIN_PREFIX)
endef

$(eval $(generic-package))
