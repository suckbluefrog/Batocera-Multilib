################################################################################
#
# wine-proton-bin (prebuilt x86_64 Wine for Box64)
#
################################################################################

WINE_PROTON_BIN_VERSION = proton-10.0-3
WINE_PROTON_BIN_SITE = https://github.com/Kron4ek/Wine-Builds/releases/download/$(WINE_PROTON_BIN_VERSION)
WINE_PROTON_BIN_SOURCE = wine-proton-10.0-4-amd64-wow64.tar.xz

WINE_PROTON_BIN_LICENSE = MIT
WINE_PROTON_BIN_LICENSE_FILES = LICENSE

# Foreign-arch payload (x86_64), DO NOT ARCH-CHECK
WINE_PROTON_BIN_INSTALL_STAGING = NO
WINE_PROTON_BIN_INSTALL_TARGET = YES
WINE_PROTON_BIN_STRIP = NO
WINE_PROTON_BIN_SKIP_ARCH_CHECK = YES

WINE_PROTON_BIN_PREFIX = /usr/wine/wine-proton

define WINE_PROTON_BIN_EXTRACT_CMDS
	$(TAR) -xf $(DL_DIR)/$(WINE_PROTON_BIN_SOURCE) -C $(@D)
endef

define WINE_PROTON_BIN_INSTALL_TARGET_CMDS
	mkdir -p $(TARGET_DIR)$(WINE_PROTON_BIN_PREFIX)
	cp -a $(@D)/wine-*/* $(TARGET_DIR)$(WINE_PROTON_BIN_PREFIX)
endef

$(eval $(generic-package))
