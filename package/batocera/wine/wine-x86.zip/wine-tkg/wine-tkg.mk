################################################################################
#
# wine-tkg (prebuilt Wine runner for Box64)
#
################################################################################

WINE_TKG_VERSION = 11.1
WINE_TKG_SITE = https://github.com/Kron4ek/Wine-Builds/releases/download/$(WINE_TKG_VERSION)
WINE_TKG_SOURCE = wine-$(WINE_TKG_VERSION)-staging-tkg-amd64-wow64.tar.xz
WINE_TKG_SITE_METHOD = wget

WINE_TKG_LICENSE = LGPL-2.1+
WINE_TKG_LICENSE_FILES = COPYING

# Foreign-arch x86_64 Wine (runs via Box64)
WINE_TKG_INSTALL_STAGING = NO
WINE_TKG_INSTALL_TARGET = YES
WINE_TKG_BIN_STRIP = NO
WINE_TKG_BIN_SKIP_ARCH_CHECK = YES

# 🔑 THIS is the one Buildroot actually uses
WINE_TKG_ARCH_EXCLUDE_DIRS = usr/wine/wine-tkg

# Batocera Wine runner location
WINE_TKG_PREFIX = /usr/wine/wine-tkg

define WINE_TKG_INSTALL_TARGET_CMDS
	mkdir -p $(TARGET_DIR)$(WINE_TKG_PREFIX)
	cp -a $(@D)/* $(TARGET_DIR)$(WINE_TKG_PREFIX)
endef

$(eval $(generic-package))
