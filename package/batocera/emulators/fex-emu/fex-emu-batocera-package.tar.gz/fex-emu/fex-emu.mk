################################################################################
#
# fex-emu
#
################################################################################

FEX_EMU_VERSION = $(shell cd $(FEX_EMU_DL_DIR) 2>/dev/null && git describe --tags 2>/dev/null || echo "latest")
FEX_EMU_SITE = https://github.com/FEX-Emu/FEX.git
FEX_EMU_SITE_METHOD = git
FEX_EMU_GIT_SUBMODULES = YES
FEX_EMU_LICENSE = MIT
FEX_EMU_LICENSE_FILES = LICENSE
FEX_EMU_INSTALL_STAGING = NO
FEX_EMU_SUPPORTS_IN_SOURCE_BUILD = NO

FEX_EMU_DEPENDENCIES = \
	host-cmake \
	host-ninja \
	host-pkgconf \
	host-ccache \
	host-clang \
	host-llvm \
	host-lld \
	openssl \
	squashfs \
	squashfuse

FEX_EMU_CONF_OPTS = \
	-DCMAKE_INSTALL_PREFIX=/usr \
	-DCMAKE_BUILD_TYPE=Release \
	-DUSE_LINKER=lld \
	-DENABLE_LTO=True \
	-DBUILD_TESTING=False \
	-DENABLE_ASSERTIONS=False \
	-G Ninja

# Force Clang as compiler
FEX_EMU_CONF_ENV = \
	CC=clang \
	CXX=clang++

define FEX_EMU_CONFIGURE_CMDS
	mkdir -p $(@D)/build
	cd $(@D)/build && $(FEX_EMU_CONF_ENV) \
		$(HOST_DIR)/bin/cmake \
		$(FEX_EMU_CONF_OPTS) \
		..
endef

define FEX_EMU_BUILD_CMDS
	cd $(@D)/build && $(HOST_DIR)/bin/ninja
endef

define FEX_EMU_INSTALL_TARGET_CMDS
	cd $(@D)/build && DESTDIR=$(TARGET_DIR) $(HOST_DIR)/bin/ninja install

	# ── Init script (binfmt_misc registration) ──
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/S30fex-emu \
		$(TARGET_DIR)/etc/init.d/S30fex-emu

	# ── systemd service (optional, for systemd-based boots) ──
	$(INSTALL) -D -m 0644 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/fex-emu.service \
		$(TARGET_DIR)/usr/lib/systemd/system/fex-emu.service

	# ── First-boot welcome notification (optional) ──
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/S31fex-welcome \
		$(TARGET_DIR)/etc/init.d/S31fex-welcome

	# ── Helper scripts → /usr/bin/ ──
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-setup.sh \
		$(TARGET_DIR)/usr/bin/fex-setup
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-steam.sh \
		$(TARGET_DIR)/usr/bin/fex-steam
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-install-steam.sh \
		$(TARGET_DIR)/usr/bin/fex-install-steam
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-install-steam-xterm.sh \
		$(TARGET_DIR)/usr/bin/fex-install-steam-xterm
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-complete-setup.sh \
		$(TARGET_DIR)/usr/bin/fex-complete-setup
	$(INSTALL) -D -m 0755 \
		$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/fex-setup-ports.sh \
		$(TARGET_DIR)/usr/bin/fex-setup-ports

	# ── Port template → /usr/share/fex-emu/ports/ ──
	$(INSTALL) -D -m 0755 \
		"$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/Steam (FEX).sh" \
		"$(TARGET_DIR)/usr/share/fex-emu/ports/Steam (FEX).sh"

	# ── Auto-install Steam port to /userdata/roms/ports/ ──
	mkdir -p $(TARGET_DIR)/userdata/roms/ports
	$(INSTALL) -D -m 0755 \
		"$(BR2_EXTERNAL_BATOCERA_PATH)/package/batocera/emulators/fex-emu/scripts/Steam (FEX).sh" \
		"$(TARGET_DIR)/userdata/roms/ports/Steam (FEX).sh"
endef

$(eval $(generic-package))
