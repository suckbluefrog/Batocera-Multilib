#!/bin/bash
#
# Steam (FEX).sh — Batocera Ports launcher for Steam via FEX-Emu
#
# This file lives in /userdata/roms/ports/
# Automatically handles first-time setup in an xterm window.
#

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
LOG="/userdata/system/logs/fex-steam.log"

mkdir -p "$(dirname "$LOG")"

# ── Function: Show error via Batocera UI ──
show_error() {
    if command -v batocera-es-swissknife >/dev/null 2>&1; then
        batocera-es-swissknife --message "$1" 2>/dev/null
    fi
    echo "$1" >> "$LOG"
}

# ── Check: FEX-Emu installed? ──
if ! command -v FEXBash >/dev/null 2>&1; then
    show_error "FEX-Emu is not installed. Cannot launch Steam."
    exit 1
fi

# ── Check: RootFS configured? ──
if [ ! -d "$ROOTFS_DIR" ] || [ -z "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    # First time — launch complete setup wizard in xterm
    DISPLAY=:0.0 \
    xterm -fs 20 -maximized -fg white -bg black \
          -fa "DejaVuSansMono" -en UTF-8 \
          -T "FEX-Emu: First Time Setup" \
          -e bash -c "
            echo ''
            echo '  ╔═══════════════════════════════════════════════╗'
            echo '  ║   FEX-Emu First Time Setup Required          ║'
            echo '  ╠═══════════════════════════════════════════════╣'
            echo '  ║                                               ║'
            echo '  ║  This will download the x86_64 RootFS and    ║'
            echo '  ║  install Steam. Takes ~15-20 minutes.        ║'
            echo '  ║                                               ║'
            echo '  ╚═══════════════════════════════════════════════╝'
            echo ''
            FEX_INSIDE_XTERM=1 fex-complete-setup
            echo ''
            echo 'Press Enter to close...'
            read
          "
    # After setup, try to launch Steam
    if ! FEXBash -c "which steam" >/dev/null 2>&1; then
        show_error "Steam setup did not complete. Please try again or run: fex-complete-setup"
        exit 1
    fi
fi

# ── Check: Steam installed? ──
if ! FEXBash -c "which steam" >/dev/null 2>&1; then
    # RootFS exists but Steam not installed — install it in xterm
    DISPLAY=:0.0 \
    xterm -fs 20 -maximized -fg white -bg black \
          -fa "DejaVuSansMono" -en UTF-8 \
          -T "FEX-Emu: Installing Steam" \
          -e bash -c "
            FEX_INSIDE_XTERM=1 fex-install-steam
            echo ''
            echo 'Press Enter to close...'
            read
          "
    if ! FEXBash -c "which steam" >/dev/null 2>&1; then
        show_error "Steam installation failed. Check logs at: $LOG"
        exit 1
    fi
fi

# ── Launch Steam ──
echo "Launching Steam — $(date)" >> "$LOG"

export DISPLAY=:0.0
export MESA_GL_VERSION_OVERRIDE=4.6
export MESA_GLSL_VERSION_OVERRIDE=460
export STEAM_RUNTIME_PREFER_HOST_LIBRARIES=0
export DXVK_ASYNC=1

FEXBash -c "steam -bigpicture -steamos" >> "$LOG" 2>&1

echo "Steam exited — $(date)" >> "$LOG"
