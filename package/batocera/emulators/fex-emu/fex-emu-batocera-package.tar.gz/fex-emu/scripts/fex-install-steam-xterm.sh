#!/bin/bash
#
# fex-install-steam-xterm — Install Steam in an xterm window so user can see progress
#

# If we're NOT inside xterm already, relaunch inside one
if [ -z "$FEX_INSIDE_XTERM" ]; then
    export FEX_INSIDE_XTERM=1
    DISPLAY=:0.0 \
    xterm -fs 20 -maximized -fg white -bg black \
          -fa "DejaVuSansMono" -en UTF-8 \
          -T "FEX-Emu: Installing Steam" \
          -e bash -c "FEX_INSIDE_XTERM=1 $0 $*; echo ''; echo 'Press Enter to close...'; read" &
    exit 0
fi

# ── Now running inside xterm ──
exec 2>&1

divider() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

banner() {
    echo ""
    divider
    echo "  $1"
    divider
    echo ""
}

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
STEAM_DEB_URL="https://repo.steampowered.com/steam/archive/stable/steam-launcher_latest_all.deb"

clear
echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║         FEX-Emu Steam Installer (Visual)        ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""

# ── Pre-checks ──
echo "[Check] FEXBash..."
if ! command -v FEXBash >/dev/null 2>&1; then
    echo ""
    echo "  ✗ ERROR: FEXBash not found!"
    echo "  FEX-Emu does not appear to be installed."
    exit 1
fi
echo "  ✓ FEXBash found"

echo "[Check] RootFS..."
if [ ! -d "$ROOTFS_DIR" ] || [ -z "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo ""
    echo "  ✗ ERROR: FEX RootFS not configured!"
    echo "  Run: fex-complete-setup"
    exit 1
fi
echo "  ✓ RootFS OK"
echo ""
sleep 1

# ── Step 1 ──
banner "Step 1/4: Updating package lists..."
FEXBash -c "dpkg --configure -a 2>/dev/null; apt-get update -y" 2>&1
echo ""
echo "  ✓ Package lists updated"
sleep 1

# ── Step 2 ──
banner "Step 2/4: Installing dependencies..."
FEXBash -c "apt-get install -y wget ca-certificates software-properties-common" 2>&1
echo ""
echo "  ✓ Dependencies installed"
sleep 1

# ── Step 3 ──
banner "Step 3/4: Downloading & installing Steam..."
FEXBash -c "
    dpkg --add-architecture i386 2>/dev/null
    apt-get update -y
    cd /tmp
    wget '$STEAM_DEB_URL' -O steam-launcher.deb
    apt-get install -yf ./steam-launcher.deb
    rm -f /tmp/steam-launcher.deb
" 2>&1
echo ""
echo "  ✓ Steam package installed"
sleep 1

# ── Step 4 ──
banner "Step 4/4: Verifying..."
if FEXBash -c "which steam" >/dev/null 2>&1; then
    echo ""
    echo "  ╔══════════════════════════════════════════════════╗"
    echo "  ║          ✓ Steam installed successfully!         ║"
    echo "  ╠══════════════════════════════════════════════════╣"
    echo "  ║                                                  ║"
    echo "  ║  Launch from: Ports → Steam (FEX)               ║"
    echo "  ║  Or run:      fex-steam                          ║"
    echo "  ║                                                  ║"
    echo "  ╚══════════════════════════════════════════════════╝"
else
    echo ""
    echo "  ✗ Steam binary not found after install."
    echo "  Check logs at: /userdata/system/logs/"
fi

echo ""
