#!/bin/bash
#
# fex-complete-setup — All-in-one FEX-Emu + Steam setup wizard
#
# Handles: RootFS download → Steam install → Ports menu setup
# Displays everything in an xterm window.
#

# If not inside xterm, relaunch in one
if [ -z "$FEX_INSIDE_XTERM" ]; then
    export FEX_INSIDE_XTERM=1
    DISPLAY=:0.0 \
    xterm -fs 20 -maximized -fg white -bg black \
          -fa "DejaVuSansMono" -en UTF-8 \
          -T "FEX-Emu: Complete Setup Wizard" \
          -e bash -c "FEX_INSIDE_XTERM=1 $0 $*; echo ''; echo 'Press Enter to close...'; read" &
    exit 0
fi

# ── Now running inside xterm ──
exec 2>&1

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
STEAM_DEB_URL="https://repo.steampowered.com/steam/archive/stable/steam-launcher_latest_all.deb"
LOG="/userdata/system/logs/fex-complete-setup.log"

mkdir -p "$(dirname "$LOG")"

divider() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

banner() {
    echo ""
    divider
    echo "  $1"
    divider
    echo ""
}

clear
echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║       FEX-Emu Complete Setup Wizard             ║"
echo "  ╠══════════════════════════════════════════════════╣"
echo "  ║                                                  ║"
echo "  ║  This wizard will:                               ║"
echo "  ║    1. Check FEX-Emu installation                 ║"
echo "  ║    2. Download x86_64 RootFS (~3-5 GB)          ║"
echo "  ║    3. Install Steam                              ║"
echo "  ║    4. Verify everything works                    ║"
echo "  ║                                                  ║"
echo "  ║  Total time: ~15-20 minutes (depends on speed)  ║"
echo "  ║                                                  ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""
read -p "  Continue? (Y/n): " CONFIRM
[ "$CONFIRM" = "n" ] || [ "$CONFIRM" = "N" ] && exit 0

# ═══════════════════════════════════════════════════
# PHASE 1: Check FEX-Emu
# ═══════════════════════════════════════════════════
banner "Phase 1/4: Checking FEX-Emu installation..."

echo "  Checking FEXInterpreter..."
if ! command -v FEXInterpreter >/dev/null 2>&1; then
    echo "  ✗ FEXInterpreter not found!"
    echo "  FEX-Emu is not installed on this system."
    exit 1
fi
echo "  ✓ FEXInterpreter found"

echo "  Checking FEXBash..."
if ! command -v FEXBash >/dev/null 2>&1; then
    echo "  ✗ FEXBash not found!"
    exit 1
fi
echo "  ✓ FEXBash found"

echo "  Checking binfmt_misc..."
if [ -f "/proc/sys/fs/binfmt_misc/FEX-x86_64" ]; then
    echo "  ✓ binfmt_misc handlers registered"
else
    echo "  ⚠ binfmt_misc handlers not found, attempting registration..."
    /etc/init.d/S30fex-emu start 2>/dev/null
    if [ -f "/proc/sys/fs/binfmt_misc/FEX-x86_64" ]; then
        echo "  ✓ binfmt_misc registered successfully"
    else
        echo "  ⚠ Could not register binfmt_misc (may still work)"
    fi
fi

echo ""
echo "  ✓ Phase 1 complete"
sleep 1

# ═══════════════════════════════════════════════════
# PHASE 2: Download RootFS
# ═══════════════════════════════════════════════════
banner "Phase 2/4: Setting up x86_64 RootFS..."

if [ -d "$ROOTFS_DIR" ] && [ "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo "  ✓ RootFS already exists at: $ROOTFS_DIR"
    echo ""
    read -p "  Re-download? (y/N): " REDO
    if [ "$REDO" = "y" ] || [ "$REDO" = "Y" ]; then
        echo "  Launching FEXRootFSFetcher..."
        FEXRootFSFetcher 2>&1 | tee -a "$LOG"
    fi
else
    echo "  No RootFS found. Launching FEXRootFSFetcher..."
    echo ""
    echo "  ┌──────────────────────────────────────────────┐"
    echo "  │  When prompted:                              │"
    echo "  │    • Select 'Download' (Y)                   │"
    echo "  │    • Pick Ubuntu 22.04 or 24.04              │"
    echo "  │    • Select 'Extract' (1)                    │"
    echo "  │    • Set as default (Y)                      │"
    echo "  └──────────────────────────────────────────────┘"
    echo ""
    FEXRootFSFetcher 2>&1 | tee -a "$LOG"
fi

# Verify rootfs
if [ ! -d "$ROOTFS_DIR" ] || [ -z "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo ""
    echo "  ✗ RootFS not detected after setup."
    echo "  You may need to run FEXRootFSFetcher manually."
    read -p "  Continue anyway? (y/N): " CONT
    [ "$CONT" != "y" ] && [ "$CONT" != "Y" ] && exit 1
fi

echo ""
echo "  ✓ Phase 2 complete"
sleep 1

# ═══════════════════════════════════════════════════
# PHASE 3: Install Steam
# ═══════════════════════════════════════════════════
banner "Phase 3/4: Installing Steam..."

# Check if Steam already installed
if FEXBash -c "which steam" >/dev/null 2>&1; then
    echo "  ✓ Steam is already installed!"
    read -p "  Reinstall? (y/N): " REINSTALL
    if [ "$REINSTALL" != "y" ] && [ "$REINSTALL" != "Y" ]; then
        echo "  Skipping Steam installation."
        STEAM_OK=1
    fi
fi

if [ -z "$STEAM_OK" ]; then
    echo "  Updating packages..."
    FEXBash -c "dpkg --configure -a 2>/dev/null; apt-get update -y" 2>&1 | tee -a "$LOG"

    echo ""
    echo "  Installing dependencies..."
    FEXBash -c "apt-get install -y wget ca-certificates software-properties-common" 2>&1 | tee -a "$LOG"

    echo ""
    echo "  Downloading and installing Steam..."
    FEXBash -c "
        dpkg --add-architecture i386 2>/dev/null
        apt-get update -y
        cd /tmp
        wget '$STEAM_DEB_URL' -O steam-launcher.deb
        apt-get install -yf ./steam-launcher.deb
        rm -f /tmp/steam-launcher.deb
    " 2>&1 | tee -a "$LOG"

    if FEXBash -c "which steam" >/dev/null 2>&1; then
        echo ""
        echo "  ✓ Steam installed successfully!"
        STEAM_OK=1
    else
        echo ""
        echo "  ✗ Steam installation may have failed."
        echo "  Check log: $LOG"
    fi
fi

echo ""
echo "  ✓ Phase 3 complete"
sleep 1

# ═══════════════════════════════════════════════════
# PHASE 4: Verify & Finalize
# ═══════════════════════════════════════════════════
banner "Phase 4/4: Verifying installation..."

echo "  Testing FEXBash x86_64 emulation..."
ARCH=$(FEXBash -c "uname -m" 2>/dev/null)
if [ "$ARCH" = "x86_64" ]; then
    echo "  ✓ FEXBash reports: $ARCH (correct!)"
else
    echo "  ⚠ FEXBash reports: $ARCH (expected x86_64)"
fi

echo ""
echo "  Checking Steam port in EmulationStation..."
if [ -f "/userdata/roms/ports/Steam (FEX).sh" ]; then
    echo "  ✓ Steam port launcher found"
else
    echo "  ⚠ Steam port not in /userdata/roms/ports/"
    echo "  Installing port launcher..."
    mkdir -p /userdata/roms/ports
    if [ -f "/usr/share/fex-emu/ports/Steam (FEX).sh" ]; then
        cp "/usr/share/fex-emu/ports/Steam (FEX).sh" "/userdata/roms/ports/Steam (FEX).sh"
        chmod 755 "/userdata/roms/ports/Steam (FEX).sh"
        echo "  ✓ Port launcher installed"
    else
        echo "  ✗ Port template not found"
    fi
fi

echo ""
divider
echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║          Setup Complete!                         ║"
echo "  ╠══════════════════════════════════════════════════╣"
echo "  ║                                                  ║"
echo "  ║  FEX-Emu:    ✓ Installed & registered           ║"
if [ -n "$STEAM_OK" ]; then
echo "  ║  Steam:      ✓ Installed                        ║"
else
echo "  ║  Steam:      ⚠ Check logs                       ║"
fi
echo "  ║  Port Menu:  ✓ Ready                            ║"
echo "  ║                                                  ║"
echo "  ║  → Go to Ports → Steam (FEX) to launch!        ║"
echo "  ║  → You may need to restart EmulationStation     ║"
echo "  ║                                                  ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""
