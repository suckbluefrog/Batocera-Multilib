#!/bin/bash
#
# fex-setup — Configure FEX-Emu RootFS
#
# Downloads and configures the x86_64 rootfs needed by FEX-Emu.
#

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
LOG="/userdata/system/logs/fex-setup.log"

mkdir -p "$(dirname "$LOG")"

echo "═══════════════════════════════════════════════════"
echo "  FEX-Emu RootFS Setup"
echo "═══════════════════════════════════════════════════"
echo ""

# Check FEXInterpreter
if ! command -v FEXInterpreter >/dev/null 2>&1; then
    echo "[ERROR] FEXInterpreter not found. Is FEX-Emu installed?"
    exit 1
fi

# Check if rootfs already exists
if [ -d "$ROOTFS_DIR" ] && [ "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo "[INFO] RootFS already exists at: $ROOTFS_DIR"
    echo ""
    read -p "Re-download/update? (y/N): " REDO
    [ "$REDO" != "y" ] && [ "$REDO" != "Y" ] && exit 0
fi

echo ""
echo "Launching FEXRootFSFetcher..."
echo "  - Select 'Download' when prompted"
echo "  - Choose the latest Ubuntu version (22.04 or 24.04 recommended)"
echo "  - Select 'Extract' and set as default"
echo ""

FEXRootFSFetcher 2>&1 | tee -a "$LOG"

# Verify
if [ -d "$ROOTFS_DIR" ] && [ "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo ""
    echo "═══════════════════════════════════════════════════"
    echo "  ✓ RootFS setup complete!"
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "Test with:  FEXBash"
    echo "Then run:   uname -m   (should show x86_64)"
    echo "Type:       exit        to return"
else
    echo ""
    echo "[WARNING] RootFS directory appears empty."
    echo "Run 'FEXRootFSFetcher' manually to troubleshoot."
fi
