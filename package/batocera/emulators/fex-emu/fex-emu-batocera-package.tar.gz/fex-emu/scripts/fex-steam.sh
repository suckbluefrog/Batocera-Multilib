#!/bin/bash
#
# fex-steam — Launch Steam via FEX-Emu
#

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
LOG="/userdata/system/logs/fex-steam.log"
STEAM_BIN="/usr/bin/steam"

mkdir -p "$(dirname "$LOG")"
exec >> "$LOG" 2>&1

echo "────────────────────────────────────────"
echo "FEX Steam Launch — $(date)"
echo "────────────────────────────────────────"

# Check FEX
if ! command -v FEXBash >/dev/null 2>&1; then
    echo "[ERROR] FEXBash not found."
    exit 1
fi

# Check rootfs
if [ ! -d "$ROOTFS_DIR" ] || [ -z "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo "[ERROR] FEX RootFS not found. Run fex-complete-setup first."
    exit 1
fi

# Performance environment
export MESA_GL_VERSION_OVERRIDE=4.6
export MESA_GLSL_VERSION_OVERRIDE=460
export STEAM_RUNTIME_PREFER_HOST_LIBRARIES=0
export DXVK_ASYNC=1

echo "Launching Steam via FEX-Emu..."
FEXBash -c "steam -bigpicture -steamos" 2>&1

echo "Steam exited at $(date)"
