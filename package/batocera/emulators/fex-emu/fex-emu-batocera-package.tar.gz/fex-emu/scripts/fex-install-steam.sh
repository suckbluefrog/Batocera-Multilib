#!/bin/bash
#
# fex-install-steam — Install Steam inside FEX-Emu rootfs
#

ROOTFS_DIR="$HOME/.fex-emu/RootFS"
LOG="/userdata/system/logs/fex-steam-install.log"
STEAM_DEB_URL="https://repo.steampowered.com/steam/archive/stable/steam-launcher_latest_all.deb"

mkdir -p "$(dirname "$LOG")"

divider() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

banner() {
    echo ""
    divider
    echo "  $1"
    divider
    echo ""
}

banner "FEX-Emu Steam Installer"

# ── Pre-checks ──
echo "[Check] FEXBash..."
if ! command -v FEXBash >/dev/null 2>&1; then
    echo "[ERROR] FEXBash not found. Is FEX-Emu installed?"
    exit 1
fi
echo "  ✓ FEXBash found"

echo "[Check] RootFS..."
if [ ! -d "$ROOTFS_DIR" ] || [ -z "$(ls -A "$ROOTFS_DIR" 2>/dev/null)" ]; then
    echo "[ERROR] FEX RootFS not configured."
    echo "  Run: fex-setup   or   fex-complete-setup"
    exit 1
fi
echo "  ✓ RootFS found at $ROOTFS_DIR"
echo ""

# ── Step 1: Update packages ──
banner "Step 1/4: Updating package lists..."
FEXBash -c "dpkg --configure -a 2>/dev/null; apt-get update -y" 2>&1 | tee -a "$LOG"

# ── Step 2: Install dependencies ──
banner "Step 2/4: Installing dependencies..."
FEXBash -c "apt-get install -y wget ca-certificates software-properties-common" 2>&1 | tee -a "$LOG"

# ── Step 3: Add i386 arch & download Steam ──
banner "Step 3/4: Downloading Steam..."
FEXBash -c "
    dpkg --add-architecture i386 2>/dev/null
    apt-get update -y
    cd /tmp
    wget -q --show-progress '$STEAM_DEB_URL' -O steam-launcher.deb
    apt-get install -yf ./steam-launcher.deb
    rm -f /tmp/steam-launcher.deb
" 2>&1 | tee -a "$LOG"

# ── Step 4: Verify ──
banner "Step 4/4: Verifying installation..."
if FEXBash -c "which steam" >/dev/null 2>&1; then
    echo "  ✓ Steam installed successfully!"
    echo ""
    echo "  Launch with:  fex-steam"
    echo "  Or from:      Ports → Steam (FEX) in EmulationStation"
else
    echo "  ✗ Steam binary not found after install."
    echo "  Check log: $LOG"
    exit 1
fi

divider
echo "  Installation complete!"
divider
echo ""
