#!/bin/bash
#
# fex-setup-ports — Install FEX-Emu port launchers to EmulationStation
#

PORTS_DIR="/userdata/roms/ports"
TEMPLATE_DIR="/usr/share/fex-emu/ports"

echo "═══════════════════════════════════════════════════"
echo "  FEX-Emu Ports Setup"
echo "═══════════════════════════════════════════════════"
echo ""

mkdir -p "$PORTS_DIR"

# Install Steam port
if [ -f "$TEMPLATE_DIR/Steam (FEX).sh" ]; then
    cp "$TEMPLATE_DIR/Steam (FEX).sh" "$PORTS_DIR/Steam (FEX).sh"
    chmod 755 "$PORTS_DIR/Steam (FEX).sh"
    echo "  ✓ Installed: Steam (FEX)"
else
    echo "  ✗ Template not found: $TEMPLATE_DIR/Steam (FEX).sh"
fi

echo ""
echo "  Port launchers installed to: $PORTS_DIR"
echo ""
echo "  Restart EmulationStation to see them:"
echo "    batocera-es-swissknife --restart"
echo ""

# Optionally restart ES
read -p "  Restart EmulationStation now? (y/N): " RESTART
if [ "$RESTART" = "y" ] || [ "$RESTART" = "Y" ]; then
    echo "  Restarting EmulationStation..."
    batocera-es-swissknife --restart 2>/dev/null
fi
